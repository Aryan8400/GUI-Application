//Regular class is a subclass of Student class
public class Regular extends Student{
    //Declaring the attributes
    private int numofModules;
    private int numofCreditHours;
    private double daysPresent;
    private boolean isGrantedScholarship;
    private char attendanceGrade;

    //Creating Constructor
    public Regular(int enrollmentID, String dateOfBirth, String courseName, String studentName, String dateOfEnrollment, int courseDuration, int tutionFee,
                 int numofModules,int numofCreditHours,double daysPresent){          
     //calling superclass constructor with four parameter
     super(dateOfBirth,studentName,tutionFee,courseDuration);
     //calling superclass mutator
     super.setcourseName(courseName);
     super.setenrollmentID(enrollmentID);
     super.setdateOfEnrollment(dateOfEnrollment);
          
     //set attributes of a sub class
     this.numofModules=numofModules;
     this.numofCreditHours=numofCreditHours;
     this.daysPresent=daysPresent;
     this.isGrantedScholarship=false;
    }   
    
    //Accesor methods of regular class
    public int getnumofModules(){
      return this.numofModules;
    }
    
    public int getnumofCreditHours(){
      return this.numofCreditHours;
    }
    
    public double getdaysPresent(){
      return this.daysPresent;
    }
    
    public boolean getisGrantedScholarship(){
      return this.isGrantedScholarship;
    }
    
    //Creating a method named Presentpercentage and its parameter
    public char presentPercentage(double daysPresent){
      this.daysPresent=daysPresent;
      double presentPercentage=(this.daysPresent/(getcourseDuration()*30))*100;
    if((getcourseDuration())*30 <this.daysPresent){
       System.out.println("Your Course Duration is less than the number of Days Present");
       return ' ';
    }
    
    //checking the present Percentage and Attendance Grade
    if(presentPercentage>=80){
      attendanceGrade = 'A';
      isGrantedScholarship= true;
    }
    
    else if(presentPercentage>=60){
      attendanceGrade= 'B';
    }
    
    else if(presentPercentage>=40){
      attendanceGrade= 'C';
    }
    
    else if(presentPercentage>=20){
      attendanceGrade= 'D';
    }
    
    else{
      attendanceGrade= 'E';
    }
    
    return attendanceGrade;    
    }
    
    //Creating a method name grantCertificate
    public void grantCertificate(String courseName,int enrollmentID,String dateOfEnrollment){
        System.out.println("The Student has been graduated with courseName:"+courseName +",enrollmentID:"+enrollmentID +",dateOfEnrollment:"+dateOfEnrollment);
        if(this.isGrantedScholarship==true){
            System.out.println("The Scholarship has been granted.");
        }
    }
    
    //Displaying the methods of a regularclass
    public void display(){
        super.display();
        System.out.println("Num of modules:"+this.numofModules);
        System.out.println("Num of Credit Hours:"+this.numofCreditHours);
        System.out.println("Days Present:"+this.daysPresent);
    }  

  }
  


  
         
 
