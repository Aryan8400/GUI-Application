//Importing Libraries for the GUI Code
import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.awt.*;
import java.awt.Font;

//Define the StudentGUI class that implements Action Listener
 public class StudentGUI implements ActionListener{
     //Adding Instance class of components and attributes for GUI
     private JFrame frame;
     private JPanel panel1,panel2;
     
     //Adding Jlabel for GUI
     private JLabel RegularClass,DropOutClass;
     JLabel lblStudentName,lblEnrollmentID,lblCourseName,lblDateOfBirth,lblDateOfEnrollment,lblCourseDuration,lblTutionFee,lblNumberOfModules,
     lblNumberOfCreditHours,lblNumberOfDaysPresent,
     lblStudentName1,lblEnrollmentID1,lblCourseName1,lblDateOfBirth1,lblDateOfEnrollment1,lblCourseDuration1,lblTutionFee1,lblNumberOfRemainingModules1,
     lblNumberOfMonthsAttended1,lblDateOfDropout1;
     
     //Adding TextField for GUI
     private JTextField StudentName,EnrollmentID,CourseName,CourseDuration,TutionFee,NumberOfModules,
     NumberOfCreditHours,NumberOfDaysPresent,
     StudentName1,EnrollmentID1,CourseName1,CourseDuration1,TutionFee1,NumberOfRemainingModules1,NumberOfMonthsAttended1;
    
     //Adding the combobox in GUI 
     private JComboBox<String> DateOfBirth,DateOfEnrollment,DateOfDropout;
     private JComboBox<String> cbDate,cbMonth,cbYear;
     private JComboBox<String>cbDate1,cbMonth1,cbYear1;
     //Adding the JButton in GUI 
     private JButton addRegularStudent,addDropoutStudent1,CalculatePresentPercentage,GrantCertificate,PayBills,RemoveStudent1,Display,Clear,Display1,Clear1;
     
     //Creating an ArrayList for Student class to hold regular and dropout
     private ArrayList<Student> studentList;
     //Creating the Constructor to add all the components 
     public StudentGUI(){
         //Initialize the ArrayList as studentList
         studentList=new ArrayList<>();
         //Create the main JFrame for the GUI
         frame = new JFrame("Student GUI");
         //Panel1 for Regular Class
         panel1 = new JPanel();
         RegularClass=new JLabel("Regular Class:");
         //Addding font for regular Class
         Font labelFont = new Font("Times New Roman", Font.PLAIN, 16);
         Font titleFont = new Font("Times New Roman", Font.BOLD, 18);
         RegularClass.setBounds(306,27,200,24);
         //Adding Regular Class to Panel1
         panel1.add(RegularClass);
         
        
         //Adding lblEnrollmentID in JLabel and Setting fonts and bounds and adding it to panel1
         lblEnrollmentID=new JLabel("Enrollment ID:");
         lblEnrollmentID.setFont(new Font("Times New Roman", Font.BOLD, 16));
         lblEnrollmentID.setBounds(32,92,150,30);
         panel1.add(lblEnrollmentID);
         
         //Adding EnrollmentID in JTextField and Setting bounds and adding it to panel1
         EnrollmentID=new JTextField();
         EnrollmentID.setBounds(218,92,137,32);
         panel1.add(EnrollmentID);
         
         //Adding lblCourseName in JLabel and Setting fonts and bounds and adding it to panel1
         lblCourseName=new JLabel("Course Name:");
         lblCourseName.setFont(new Font("Times New Roman", Font.BOLD, 16));
         lblCourseName.setBounds(32,147,150,30);
         panel1.add(lblCourseName);
         
         //Adding CourseName in JTextField and Setting bounds and adding it to panel1
         CourseName=new JTextField();
         CourseName.setBounds(218,147,137,32);
         panel1.add(CourseName);
         
         //Adding lblStudentName in JLabel and Setting fonts and bounds and adding it to panel1
         lblStudentName=new JLabel("Student Name:");
         lblStudentName.setFont(new Font("Times New Roman", Font.BOLD, 16));
         lblStudentName.setBounds(32,257,104,30);         
         panel1.add(lblStudentName);
         
         //Adding StudentName JTextField and Setting bounds and adding it to panel1
         StudentName=new JTextField();
         StudentName.setBounds(218,257,137,32);
         panel1.add(StudentName);
         
         //Adding lblDateOfBirth in JLabel and Setting fonts and bounds and adding it to panel1
         lblDateOfBirth=new JLabel("Date Of Birth:");
         lblDateOfBirth.setFont(new Font("Times New Roman", Font.BOLD, 16));
         lblDateOfBirth.setBounds(32,312,144,30);
         panel1.add(lblDateOfBirth);
         //Adding Date,Month,Year in a ArrayList
         String Date[]={"1","2","3","4","5","6","7","8","9","10",};
         String Month[]={"January","February","March","April","May","June","July","August"};
         String Year[]={"2000","2001","2002","2003","2004","2005","2006","2007","2008","2009","2010"};
         cbDate=new JComboBox<String>(Date);
         cbDate.setBounds(218,312,82,32);
         panel1.add(cbDate);
         cbMonth=new JComboBox<String>(Month);
         cbMonth.setBounds(318,312,82,32);
         panel1.add(cbMonth);
         cbYear=new JComboBox<String>(Year);
         cbYear.setBounds(413,312,107,32);
         panel1.add(cbYear);
         
         //Adding  lblDateOfEnrollment in JLabel and Setting fonts and bounds and adding it to panel1
         lblDateOfEnrollment=new JLabel("Date Of Enrollment:");
         lblDateOfEnrollment.setFont(new Font("Times New Roman", Font.BOLD, 16));
         lblDateOfEnrollment.setBounds(32,202,144,30);
         panel1.add(lblDateOfEnrollment);
         
         //Adding Date,Month,Year in a ArrayList
         cbDate=new JComboBox<String>(Date);
         cbDate.setBounds(218,202,82,32);
         panel1.add(cbDate);
         cbMonth=new JComboBox<String>(Month);
         cbMonth.setBounds(318,202,82,32);
         panel1.add(cbMonth);
         cbYear=new JComboBox<String>(Year);
         cbYear.setBounds(413,202,107,32);
         panel1.add(cbYear);
         
         //Adding lblCourseDuration in JLabel and Setting fonts and bounds and adding it to panel1
         lblCourseDuration=new JLabel("Course Duration:");
         lblCourseDuration.setFont(new Font("Times New Roman", Font.BOLD, 16));
         lblCourseDuration.setBounds(32,367,127,30);
         panel1.add(lblCourseDuration);
         
         //Adding  CourseDuration in JTextField and Setting bounds and adding it to panel1
         CourseDuration=new JTextField();
         CourseDuration.setBounds(218,367,137,32);
         panel1.add(CourseDuration);
         
         //Adding lblTutionFee  in JLabel and Setting fonts and bounds and adding it to panel1
         lblTutionFee=new JLabel("Tution Fee:");
         lblTutionFee.setFont(new Font("Times New Roman", Font.BOLD, 16));
         lblTutionFee.setBounds(32,422,127,30);
         panel1.add(lblTutionFee);
         
         //Adding TutionFee in JTextField and Setting bounds and adding it to panel1
         TutionFee=new JTextField();
         TutionFee.setBounds(218,422,137,32);
         panel1.add(TutionFee);
         
         //Adding lblNumberOfModules in JLabel and Setting fonts and bounds and adding it to panel1
         lblNumberOfModules=new JLabel("Number Of Modules:");
         lblNumberOfModules.setFont(new Font("Times New Roman", Font.BOLD, 16));
         lblNumberOfModules.setBounds(32,532,164,30);
         panel1.add(lblNumberOfModules);
         
         //Adding NumberOfModules in JTextField and Setting bounds and adding it to panel1
         NumberOfModules=new JTextField();
         NumberOfModules.setBounds(218,532,137,32);
         panel1.add(NumberOfModules);
         
         //Adding lblNumberOfCreditHours in JLabel and Setting fonts and bounds and adding it to panel1
         lblNumberOfCreditHours=new JLabel("Number Of Credit Hours:");
         lblNumberOfCreditHours.setFont(new Font("Times New Roman", Font.BOLD, 16));
         lblNumberOfCreditHours.setBounds(32,477,180,30);
         panel1.add(lblNumberOfCreditHours);
         
         //Adding NumberOfCreditHours in JTextField and Setting bounds and adding it to panel1
         NumberOfCreditHours=new JTextField();
         NumberOfCreditHours.setBounds(218,477,137,32);
         panel1.add(NumberOfCreditHours);
         
         //Adding lblNumberOfDaysPresent in JLabel and Setting fonts and bounds and adding it to panel1
         lblNumberOfDaysPresent=new JLabel("Days Present:");
         lblNumberOfDaysPresent.setFont(new Font("Times New Roman", Font.BOLD, 16));
         lblNumberOfDaysPresent.setBounds(32,587,103,25);
         panel1.add(lblNumberOfDaysPresent);
         
         //Adding NumberOfDaysPresent in JTextField and Setting bounds and adding it to panel1
         NumberOfDaysPresent=new JTextField();
         NumberOfDaysPresent.setBounds(218,587,137,32);
         panel1.add(NumberOfDaysPresent);
         
         //Adding JButtion GrantCertificate and Setting Bounds and adding it to panel1
         GrantCertificate=new JButton("Grant Certificate");
         GrantCertificate.setBackground(new Color(241, 196, 15));
         GrantCertificate.setBounds(568,217,153,33);
         panel1.add(GrantCertificate);
         
         //Adding JButtion addRegularStudent and Setting Bounds and addding it to panel1
         addRegularStudent=new JButton("Add");
         addRegularStudent.setBackground(new Color(59, 89, 182));
         addRegularStudent.setBounds(413,587,120,32);
         panel1.add(addRegularStudent);
         
        //Adding JButtion CalculatePresentPercentage and Setting Bounds and addding it to panel1
         CalculatePresentPercentage=new JButton("Calculate Present Percentage");
         CalculatePresentPercentage.setBackground(new Color(46, 204, 113));
         CalculatePresentPercentage.setBounds(570,587,210,32);
         panel1.add(CalculatePresentPercentage);
         
        //Adding JButtion Display and Setting Bounds and addding it to panel1
         Display=new JButton("Display");
         Display.setBackground(new Color(155, 89, 182));
         Display.setBounds(218,672,120,32);
         panel1.add(Display);
        
         //Adding JButtion Clear and Setting Bounds and addding it to panel1
         Clear=new JButton("Clear");
         Clear.setBackground(new Color(149, 165, 166));
         Clear.setBounds(368,672,120,32);
         panel1.add(Clear);
        
         //Creating a panel2 for Dropout class
         panel2 = new JPanel();
         //Adding GUI Components for DropOut Class
         DropOutClass=new JLabel("Dropout Class:");
         DropOutClass.setBounds(1035,27,204,27);
         panel2.add(DropOutClass);
         
         //Adding lblEnrollmentID1 in JLabel and Setting fonts and bounds and adding it to panel2
         lblEnrollmentID1 = new JLabel("Enrollment ID:");
         lblEnrollmentID1.setFont(new Font("Times New Roman", Font.BOLD, 16));
         lblEnrollmentID1.setBounds(821,92,109,25);
         panel2.add(lblEnrollmentID1);  
         
         //Adding EnrollmentID1 in JTextField and Setting bounds and adding it to panel2
         EnrollmentID1=new JTextField();
         EnrollmentID1.setBounds(1055,92,137,32);
         panel2.add(EnrollmentID1);
         
         //Adding lblCourseName in JLabel and Setting fonts and bounds and adding it to panel2
         lblCourseName1=new JLabel("Course Name:");
         lblCourseName1.setFont(new Font("Times New Roman", Font.BOLD, 16));
         lblCourseName1.setBounds(821,147,104,25);
         panel2.add(lblCourseName1);
        
         //Adding CourseName1 in JTextField and Setting bounds and adding it to panel2
         CourseName1=new JTextField();
         CourseName1.setBounds(1055,147,137,32);
         panel2.add(CourseName1);
         
         //Adding lblStudentName1 in JLabel and Setting fonts and bounds and adding it to panel2
         lblStudentName1=new JLabel("Student Name:");
         lblStudentName1.setFont(new Font("Times New Roman", Font.BOLD, 16));
         lblStudentName1.setBounds(821,202,132,25);         
         panel2.add(lblStudentName1);
         
         //Adding StudentName1 in JTextField and Setting bounds and adding it to panel2
         StudentName1=new JTextField();
         StudentName1.setBounds(1055,202,137,32);
         panel2.add(StudentName1);
         
         //Adding lblDateOfBirth1 in JLabel and Setting fonts and bounds and adding it to panel2
         lblDateOfBirth1=new JLabel("Date Of Birth:");
         lblDateOfBirth1.setFont(new Font("Times New Roman", Font.BOLD, 16));
         lblDateOfBirth1.setBounds(821,257,112,25);
         panel2.add(lblDateOfBirth1);
         //Adding Date,Month,Year in a ArrayList
         String Date1[]={"1","2","3","4","5","6","7","8","9","10",};
         String Month1[]={"January","February","March","April","May","June","July","August"};
         String Year1[]={"2000","2001","2002","2003","2004","2005","2006","2007","2008","2009","2010"};
         cbDate1=new JComboBox<String>(Date1);
         cbDate1.setBounds(1055,257,90,32);
         panel2.add(cbDate1);
         cbMonth1=new JComboBox<String>(Month1);
         cbMonth1.setBounds(1155,257,90,32);
         panel2.add(cbMonth1);
         cbYear1=new JComboBox<String>(Year1);
         cbYear1.setBounds(1260,257,107,32);
         panel2.add(cbYear1);
         
         //Adding lblDateOfEnrollment1 in JLabel and Setting fonts and bounds and adding it to panel2
         lblDateOfEnrollment1=new JLabel("Date Of Enrollment:");
         lblDateOfEnrollment1.setFont(new Font("Times New Roman", Font.BOLD, 16));
         lblDateOfEnrollment1.setBounds(821,312,144,25);
         panel2.add(lblDateOfEnrollment1);
         //Adding Date,Month,Year in a ArrayList
         cbDate1=new JComboBox<String>(Date1);
         cbDate1.setBounds(1055,312,90,32);
         panel2.add(cbDate1);
         cbMonth1=new JComboBox<String>(Month1);
         cbMonth1.setBounds(1155,312,90,32);
         panel2.add(cbMonth1);
         cbYear1=new JComboBox<String>(Year1);
         cbYear1.setBounds(1260,312,107,32);
         panel2.add(cbYear1);
         
         //Adding lblCourseDuration1 in JLabel and Setting fonts and bounds and adding it to panel2
         lblCourseDuration1=new JLabel("Course Duration:");
         lblCourseDuration1.setFont(new Font("Times New Roman", Font.BOLD, 16));
         lblCourseDuration1.setBounds(821,363,127,25);
         panel2.add(lblCourseDuration1);
         
         //Adding CourseDuration1 in JTextField and Setting bounds and adding it to panel2
         CourseDuration1=new JTextField();
         CourseDuration1.setBounds(1055,367,137,32);
         panel2.add(CourseDuration1);
         
         //Adding lblTutionFee1 in JLabel and Setting fonts and bounds and adding it to panel2
         lblTutionFee1=new JLabel("Tution Fee:");
         lblTutionFee1.setFont(new Font("Times New Roman", Font.BOLD, 16));
         lblTutionFee1.setBounds(821,418,85,25);
         panel2.add(lblTutionFee1);
         
         //Adding TutionFee1 in JTextField and Setting bounds and adding it to panel2
         TutionFee1=new JTextField();
         TutionFee1.setBounds(1055,418,137,32);
         panel2.add(TutionFee1);
         
         //Adding lblNumberOfRemainingModules1 in JLabel and Setting fonts and bounds and adding it to panel2
         lblNumberOfRemainingModules1=new JLabel("Number Of Remaining Modules:");
         lblNumberOfRemainingModules1.setFont(new Font("Times New Roman", Font.BOLD, 16));
         lblNumberOfRemainingModules1.setBounds(821,473,245,25);
         panel2.add(lblNumberOfRemainingModules1);
         
         //Adding NumberOfRemainingModules1 in JTextField and Setting bounds and adding it to panel2
         NumberOfRemainingModules1=new JTextField();
         NumberOfRemainingModules1.setBounds(1055,473,137,32);
         panel2.add(NumberOfRemainingModules1);
         
         //Adding lblMonthsAttended1 in JLabel and Setting fonts and bounds and adding it to panel2
         lblNumberOfMonthsAttended1=new JLabel("Number Of Months Attended:");
         lblNumberOfMonthsAttended1.setFont(new Font("Times New Roman", Font.BOLD, 16));
         lblNumberOfMonthsAttended1.setBounds(821,532,221,25);
         panel2.add(lblNumberOfMonthsAttended1);
        
         //Adding NumberOfMonthsAttended1 in JTextField and Setting bounds and adding it to panel2
         NumberOfMonthsAttended1=new JTextField();
         NumberOfMonthsAttended1.setBounds(1055,532,137,32);
         panel2.add(NumberOfMonthsAttended1);
         
         //Adding lblDateOfDropout1 in JLabel and Setting fonts and bounds and adding it to panel2
         lblDateOfDropout1=new JLabel("Date Of Dropout:");
         lblDateOfDropout1.setFont(new Font("Times New Roman", Font.BOLD, 16));
         lblDateOfDropout1.setBounds(821,583,127,25);
         panel2.add(lblDateOfDropout1);
         
         cbDate1=new JComboBox<String>(Date1);
         cbDate1.setBounds(1055,582,82,32);
         panel2.add(cbDate1);
         cbMonth1=new JComboBox<String>(Month1);
         cbMonth1.setBounds(1155,582,82,32);
         panel2.add(cbMonth1);
         cbYear1=new JComboBox<String>(Year1);
         cbYear1.setBounds(1260,582,107,32);
         panel2.add(cbYear1);
         
         
         //Adding JButton in Regular Class with the background colour and bounds
        //Adding JButton addDropoutStudent1 and Setting Bounds and adding it to panel2
         addDropoutStudent1=new JButton("Add");
         addDropoutStudent1.setBackground(new Color(59, 89, 182));
         addDropoutStudent1.setBounds(1390,585,120,32);
         panel2.add(addDropoutStudent1);
         
         //Adding JButton  PayBills and Setting Bounds and adding it to panel2
         PayBills=new JButton("Pay Bills");
         PayBills.setBackground(new Color(46, 204, 113));
         PayBills.setBounds(1279,103,120,32);
         panel2.add(PayBills);
         
         //Adding JButton RemoveStudent1 and Setting Bounds and adding it to panel2
         RemoveStudent1=new JButton("Remove Student");
         RemoveStudent1.setBackground(new Color(231, 76, 60));
         RemoveStudent1.setBounds(1279,163,158,32);
         panel2.add(RemoveStudent1);
         
         //Adding JButton Display1  and Setting Bounds and adding it to panel2
         Display1=new JButton("Display");
         Display1.setBackground(new Color(155, 89, 182));
         Display1.setBounds(918,672,120,32);
         panel2.add(Display1);
         
         //Adding JButton Clear1 and Setting Bounds and adding it to panel2
         Clear1=new JButton("Clear");
         Clear1.setBackground(new Color(149, 165, 166));
         Clear1.setBounds(1100,672,120,32);
         panel2.add(Clear1);
         
        //Displaying JFrame
        //Setting background and Foreground for the panels
        panel1.setBackground(new Color(103, 183, 220));
        panel1.setForeground(Color.WHITE);
        panel2.setBackground(new Color(144, 206, 161));
        panel2.setForeground(Color.WHITE);
        
        //Setting the layout of the panel to null
        panel1.setLayout(null);
        panel2.setLayout(null);
        
        //Add ActionListener to the buttons
        addRegularStudent.addActionListener(this);
        addDropoutStudent1.addActionListener(this);
        CalculatePresentPercentage.addActionListener(this);
        GrantCertificate.addActionListener(this);
        PayBills.addActionListener(this);
        RemoveStudent1.addActionListener(this);
        Display.addActionListener(this);
        Clear.addActionListener(this);
        Display1.addActionListener(this);
        Clear1.addActionListener(this);
        
        // Set the bounds for panel1 and panel2
        panel1.setBounds(0, 0, 800, 786);
        panel2.setBounds(800, 0, 816, 786); 
        //Adding panels to the frame
        frame.add(panel1);
        frame.add(panel2);
        //frame.setLayout(null);
        //Setting of the frame and using Resizable for the actual size of the frame
        frame.setSize(1616,788);
        //Setting the frame as true for visible
        frame.setVisible(true);
        frame.setResizable(false);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        //Set fonts for regular Class and DropOut class
        RegularClass.setFont(new Font("Times New Roman", Font.BOLD, 20));
        DropOutClass.setFont(new Font("Times New Roman", Font.BOLD, 20));
    }
    
    @Override
    //Using ActionPerformed method to handle button clicks
    public void actionPerformed(ActionEvent a)
    {   
        //Adding RegularStudent Button to Regular
        if(a.getSource() == addRegularStudent){
            //Checking if the text field are empty  or not
            if(StudentName.getText().isEmpty()||EnrollmentID.getText().isEmpty()||CourseName.getText().isEmpty()||CourseDuration.getText().isEmpty()||
            TutionFee.getText().isEmpty()||NumberOfModules.getText().isEmpty()|| NumberOfCreditHours.getText().isEmpty()||
            NumberOfDaysPresent.getText().isEmpty())
            {
              //Displaying the warning message if text field is empty
              JOptionPane.showMessageDialog(frame, "TextField cannot be empty", "Warning", JOptionPane.WARNING_MESSAGE);
            }
            else
               {
                try 
                  {
                   //Parsing Input from the textfields
                   String studentName = StudentName.getText();
                   int enrollmentID = Integer.parseInt(EnrollmentID.getText());
                   String courseName = CourseName.getText();
                   String dateOfBirth = cbDate.getSelectedItem().toString() + " " + cbMonth.getSelectedItem().toString() + " " + cbYear.getSelectedItem().toString();
                   String dateOfEnrollment = cbDate1.getSelectedItem().toString() + " " + cbMonth1.getSelectedItem().toString() + " " + cbYear1.getSelectedItem().toString();
                   int courseDuration = Integer.parseInt(CourseDuration.getText());
                   int tuitionFee = Integer.parseInt(TutionFee.getText());
                   int numberOfModules = Integer.parseInt(NumberOfModules.getText());
                   int numberOfCreditHours = Integer.parseInt(NumberOfCreditHours.getText());
                   double daysPresent = Double.parseDouble(NumberOfDaysPresent.getText());
                   
                   //Using this condition for not to add number less than 1
                   if(enrollmentID <= 0)
                   {
                       JOptionPane.showMessageDialog(frame, "Invalid input. Please enter valid number.", "Error", JOptionPane.ERROR_MESSAGE);
                   }
                   else{
                   //Creating a method regularStudent to hold all the date collected 
                   Regular regularStudent = new Regular(enrollmentID, dateOfBirth, courseName, studentName, dateOfEnrollment, courseDuration, tuitionFee, numberOfModules, numberOfCreditHours, daysPresent);
                   // Check for duplicates based on enrollment ID
                   boolean isDuplicate = false;
                  for (Student student : studentList) {
                    if (student instanceof Regular && student.getenrollmentID() == enrollmentID) {
                    isDuplicate = true;
                    break;
                }
            }
            
        

            if (isDuplicate) {
                JOptionPane.showMessageDialog(frame, "Student with the same enrollment ID already exists.", "Duplicate Student", JOptionPane.WARNING_MESSAGE);
            }
                  
                   else{
                   //Adding Regular Student into the arraylist
                   studentList.add(regularStudent);
                   //Displaying it after it has been added 
                   JOptionPane.showMessageDialog(frame, "Regular student added successfully.");
                   //using clear method to  clear the textfield after it is been added
                   Clear();
                 } 
                }
                  //using NumberFormatException if there is wrong input in textfield
                }catch (NumberFormatException e) {
                   JOptionPane.showMessageDialog(frame, "Invalid input. Please enter valid number.", "Error", JOptionPane.ERROR_MESSAGE);
                  }
          
            }
        }
         //Adding DropOutStudent Button to Regular
        else if (a.getSource() == addDropoutStudent1)
        {
             //Checking if the text field are empty  or not
             if (StudentName1.getText().isEmpty() || EnrollmentID1.getText().isEmpty() || CourseName1.getText().isEmpty()
                || CourseDuration1.getText().isEmpty() || TutionFee1.getText().isEmpty()
                || NumberOfRemainingModules1.getText().isEmpty() || NumberOfMonthsAttended1.getText().isEmpty()) 
                {
                   //Displaying the message if text field is empty 
                  JOptionPane.showMessageDialog(frame, "TextField cannot be empty", "Warning", JOptionPane.WARNING_MESSAGE);
                } 
             else{
                 try
                    {
                      //Setting the variable for the textfields
                     String studentName = StudentName1.getText();
                     int enrollmentID = Integer.parseInt(EnrollmentID1.getText());
                     String courseName = CourseName1.getText();
                     String dateOfBirth = cbDate1.getSelectedItem().toString() + " "
                            + cbMonth1.getSelectedItem().toString() + " " + cbYear1.getSelectedItem().toString();
                     String dateOfEnrollment = cbDate1.getSelectedItem().toString() + " "
                            + cbMonth1.getSelectedItem().toString() + " " + cbYear1.getSelectedItem().toString();
                     String dateofDropout = cbDate1.getSelectedItem().toString() + " "
                            + cbMonth1.getSelectedItem().toString() + " " + cbYear1.getSelectedItem().toString();      
                     int courseDuration = Integer.parseInt(CourseDuration1.getText());
                     int tutionFee = Integer.parseInt(TutionFee1.getText());
                     int numberOfRemainingModules = Integer.parseInt(NumberOfRemainingModules1.getText());
                     int numberOfMonthsAttended = Integer.parseInt(NumberOfMonthsAttended1.getText());
                     //Using this condition for not to add number less than 1
                     if(enrollmentID <= 0){
                       JOptionPane.showMessageDialog(frame, "Invalid input. Please enter valid number.", "Error", JOptionPane.ERROR_MESSAGE);
                   }
                    else{
                        //Create the dropout object to hold the data
                     Dropout dropoutStudent = new Dropout(dateOfBirth, studentName, courseDuration, tutionFee,
                     numberOfRemainingModules, numberOfMonthsAttended,dateofDropout,enrollmentID,courseName,dateOfEnrollment);
                     
                     // Check for duplicates based on enrollment ID
                      boolean isDuplicate = false;
                      for (Student student : studentList) 
                      {
                        if (student instanceof Dropout && student.getenrollmentID() == enrollmentID)
                        {
                         isDuplicate = true;
                         break;
                        }
                      }
                      if (isDuplicate) 
                      {
                          JOptionPane.showMessageDialog(frame, "Student with the same enrollment ID already exists.", "Duplicate Student", JOptionPane.WARNING_MESSAGE);
                      }

                    
                     else{
                    //Adding it into the arraylist
                     studentList.add(dropoutStudent);
                      //Displaying it after it has been added 
                     JOptionPane.showMessageDialog(frame, "Dropout student added successfully.");
                     //using clear method to  clear the textfield after it is been added
                     Clear1();
                    }
                     
                 } 
                }
                  //using NumberFormatException if there is wrong input in textfield
                   catch (NumberFormatException e) 
                   {
                    JOptionPane.showMessageDialog(frame, "Invalid input. Please enter a valid number.", "Error",
                            JOptionPane.ERROR_MESSAGE);
                   }
             }
       }
        //Adding CalculatePresentPercentage to the regular
        else if (a.getSource() == CalculatePresentPercentage) 
        {
            //Checking if the textfield are empty or not and displaying a warning message
             if (EnrollmentID.getText().isEmpty() || NumberOfDaysPresent.getText().isEmpty())
            {
               JOptionPane.showMessageDialog(frame, "Please enter EnrollmentId,NumberOfDaysPresent", "Warning", JOptionPane.WARNING_MESSAGE);
            }
            else{
          try 
           {
               //Setting the variables for textfield
               int enrollmentID = Integer.parseInt(EnrollmentID.getText());
               int daysPresent = Integer.parseInt(NumberOfDaysPresent.getText());
               //Checking the duplicate value based on enrollmentID 
               boolean validEnrollmentID = true;
               for (Student student : studentList) 
               {
                 if (student instanceof Regular && student.getenrollmentID() == enrollmentID)
                {
                  Regular regularStudent = (Regular) student;
                  //Using presentpercentage method to calculate the present percentage of a student
                  regularStudent.presentPercentage(daysPresent);
                  JOptionPane.showMessageDialog(frame, "Present Percentage is calculated.");
                  validEnrollmentID = false;
                  break;
                 }
               }
              //Checking if the EnrollmentId is valid or not
              if (validEnrollmentID) 
              {
                  JOptionPane.showMessageDialog(frame, "Regular student with the given Enrollment ID not found.", "Error", JOptionPane.ERROR_MESSAGE);
              }
          } 
             //using NumberFormatException if there is wrong input in textfield
             catch (NumberFormatException e) 
              {
                JOptionPane.showMessageDialog(frame, "Invalid input. Please enter a valid number.", "Error",JOptionPane.ERROR_MESSAGE);
              }
        }
    }   
        //Adding GrantCertificate button to the Regualar
        else if (a.getSource() == GrantCertificate) 
        {
            //Checking whether the text field are empty or not
            if (EnrollmentID.getText().isEmpty() || CourseName.getText().isEmpty())
            {
               JOptionPane.showMessageDialog(frame, "Please enter EnrollmentId,CourseName and DateOfEnrollment", "Warning", JOptionPane.WARNING_MESSAGE);
            }
            else{
                //Setting the variables for textfield
                String courseName = CourseName.getText();
                String dateOfEnrollment = cbDate.getSelectedItem().toString() + " " + cbMonth.getSelectedItem().toString()
                                         + " " + cbYear.getSelectedItem().toString();
                try
                {
                    int enrollmentID=Integer.parseInt(EnrollmentID.getText());
                    if(studentList.isEmpty())
                    {
                        JOptionPane.showMessageDialog(frame,"Student List is empty");
                    }
                    else
                    {
                      boolean grantCertificate=false;
                       for (Student student : studentList)
                       {
                           if(student instanceof Regular && student.getenrollmentID() == enrollmentID)
                            {
                             Regular regularStudent = (Regular) student;
                             grantCertificate=true;
                             regularStudent.grantCertificate(courseName,enrollmentID,dateOfEnrollment);
                             //Displaying the messsage If the student has granted the certificate
                             JOptionPane.showMessageDialog(frame,"Granted Certificated.");
                             break;
                           }
                       }
                       //Checking if the Student with the enrollmentID has not not be found
                       if(grantCertificate==false)
                        {
                            //Display message
                            JOptionPane.showMessageDialog(frame, "Regular student with the given Enrollment ID not found.", "Error", JOptionPane.ERROR_MESSAGE);
                        }
                    }
                    
                    
                }
                //Using NumberFormatException if the wrong input is entered in the textfield
                catch (NumberFormatException e) 
                {
                  JOptionPane.showMessageDialog(frame, "Invalid input. Please enter a valid number.", "Error",JOptionPane.ERROR_MESSAGE);
                }
                
          }
        }  
        //Adding Paybills Button to the Dropout
        else if (a.getSource() == PayBills) {
            //Checking whether the text field are empty or not
            if (EnrollmentID1.getText().isEmpty())
            {
               JOptionPane.showMessageDialog(frame, "Please enter EnrollmentId", "Warning", JOptionPane.WARNING_MESSAGE);
            }
            else{    
             try {
             // Parse enrollment ID as an integer
              int enrollmentID=Integer.parseInt(EnrollmentID1.getText());
              boolean validEnrollmentID = true;
            // Finding the Dropout student with the given enrollment ID in the studentsList
            for (Student student : studentList) {
                if (student instanceof Dropout && student.getenrollmentID() == enrollmentID)
                {
                    Dropout dropoutStudent = (Dropout) student;
                    //Using Bills payable method form dropout class to pay the bills
                    dropoutStudent.billsPayable();
                    //Dispalaying the message
                    JOptionPane.showMessageDialog(frame, "Remaining amount is calculated.");
                    validEnrollmentID = false;
                    break;
                }
            }

            // If a Dropout student with the given enrollment ID is found, pay the bills
            if (validEnrollmentID)  {
               
                JOptionPane.showMessageDialog(frame, "DropOut Student with the provided enrollment ID not found.", "Error", JOptionPane.ERROR_MESSAGE);
            }
            
        } 
        //Using NumberFormatException if the wrong input is entered in the textfield
        catch (NumberFormatException ex) {
           JOptionPane.showMessageDialog(frame, "Invalid input. Please enter a valid number.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
  }     
        
        //Adding RemoveStudentButton1 button to the DropOut
        else if(a.getSource() == RemoveStudent1)
        {   
            //checking if the textfield are empty or not 
            if(EnrollmentID1.getText().isEmpty()){
                
                JOptionPane.showMessageDialog(frame,"Please enter an erollmentID","Warning",JOptionPane.WARNING_MESSAGE);
        }
        else
        {
            try{
                // Parse enrollment ID as an integer
                int enrollmentID = Integer.parseInt(EnrollmentID1.getText());
                // Finding the Dropout student with the given enrollment ID in the studentsList
                for(Student student: studentList)
                {
                    if (student instanceof Dropout && student.getenrollmentID() == enrollmentID)
                    {
                        Dropout d = (Dropout) student;
                        //using hasPaid method to check if the student has payed the bill or not
                        if(d.gethasPaid())
                        {
                            //Displaying the message after it is removed
                            JOptionPane.showMessageDialog(frame,"The student is removed","Information",JOptionPane.INFORMATION_MESSAGE);
                            break;

                        }
                        else
                        {
                            //Displaying the warning message to clear all the dues
                            JOptionPane.showMessageDialog(frame,"Please clear all the dues","Warning",JOptionPane.WARNING_MESSAGE);
                            break;

                        }
                    }
                }
            }
            //using NuberFormatException for invalid Input
            catch(NumberFormatException e)
            {
                JOptionPane.showMessageDialog(frame,"invaild Enrollment ID","Warning",JOptionPane.WARNING_MESSAGE);

            }
        }
    
    }
        //Adding Display Button to the Regular   
        else if (a.getSource()== Display){
           for (Student student : studentList) 
               {
                 if (student instanceof Regular)
                 {
                     Regular r = (Regular) student;
                     //Displaying the message of regular Student
                     r.display();
                     JOptionPane.showMessageDialog(frame,"Display Message","Information",JOptionPane.INFORMATION_MESSAGE);
                 }
               }
            }
            //Adding Display1 Button to the DropOut
            else if (a.getSource()== Display1){
            for (Student student : studentList) 
               {
                 if (student instanceof Dropout)
                 {
                     Dropout r = (Dropout) student;
                     //Displaying the message of DropOut Student
                     r.display();
                     JOptionPane.showMessageDialog(frame,"Display Message","Information",JOptionPane.INFORMATION_MESSAGE);
                     
                 }
               }
        }
        //Adding Clear Button for Clear 
        else if (a.getSource() == Clear)
         {
            //Clearing the textfield by inputing empty field and for combobox set it as Index(0)
            StudentName.setText("");
            EnrollmentID.setText("");
            CourseName.setText("");
            CourseDuration.setText("");
            TutionFee.setText("");
            NumberOfModules.setText("");
            NumberOfCreditHours.setText("");
            NumberOfDaysPresent.setText("");
            cbDate.setSelectedIndex(0);
            cbMonth.setSelectedIndex(0);
            cbYear.setSelectedIndex(0);
            cbDate.setSelectedIndex(0);
            cbMonth.setSelectedIndex(0);
            cbYear.setSelectedIndex(0);
        }
         //Adding Clear Button for Clear 
         else if (a.getSource() == Clear1)
         {
          //Clearing the textfield by inputing empty field and for combobox set it as Index(0)
          StudentName1.setText("");
          EnrollmentID1.setText("");
          CourseName1.setText("");
          CourseDuration1.setText("");
          TutionFee1.setText("");
          NumberOfRemainingModules1.setText("");
          NumberOfMonthsAttended1.setText("");
          cbDate1.setSelectedIndex(0);
          cbMonth1.setSelectedIndex(0);
          cbYear1.setSelectedIndex(0);
          cbDate1.setSelectedIndex(0);
          cbMonth1.setSelectedIndex(0);
          cbYear1.setSelectedIndex(0);
         }
         
   }
   
    //Creating a method Clear to add it into a regualar After adding a input in Regular the method will clear the textfield 
    public void Clear() {
      StudentName.setText("");
      EnrollmentID.setText("");
      CourseName.setText("");
      CourseDuration.setText("");
      TutionFee.setText("");
      NumberOfModules.setText("");
      NumberOfCreditHours.setText("");
      NumberOfDaysPresent.setText("");
      cbDate.setSelectedIndex(0);
      cbMonth.setSelectedIndex(0);
      cbYear.setSelectedIndex(0);
      cbDate.setSelectedIndex(0);
      cbMonth.setSelectedIndex(0);
      cbYear.setSelectedIndex(0);
     }
     //Creating a method Clear to add it into a DropOut After adding a input in Dropout the method will clear the textfield  
     public void Clear1() {
        StudentName1.setText("");
        EnrollmentID1.setText("");
        CourseName1.setText("");
        CourseDuration1.setText("");
        TutionFee1.setText("");
        NumberOfRemainingModules1.setText("");
        NumberOfMonthsAttended1.setText("");
        cbDate1.setSelectedIndex(0);
        cbMonth1.setSelectedIndex(0);
        cbYear1.setSelectedIndex(0);
        cbDate1.setSelectedIndex(0);
        cbMonth1.setSelectedIndex(0);
        cbYear1.setSelectedIndex(0);
     }
     
    //Creating a main method
    public static void main(String[]args){
        new StudentGUI();
    }
}

        

    
 
    


