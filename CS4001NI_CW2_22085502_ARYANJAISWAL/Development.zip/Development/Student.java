//Creating a Parentclass
public class Student{
   //Class attributes
   private int enrollmentID;
   private String dateOfBirth;
   private String courseName;
   private String studentName;
   private String dateofEnrollment;
   private int courseDuration;
   private int tutionFee;
   
   //creating constructors
    public Student(String dateOfBirth,String studentName,int tuitionFee,int courseDuration){
     this.enrollmentID=0;
     this.dateOfBirth=dateOfBirth;
     this.courseName=" ";
     this.studentName = studentName;
     this.dateofEnrollment=" ";
     this.courseDuration= courseDuration;
     this.tutionFee= tuitionFee;
    }
    
    //Corresponding Acessor Method
    public int getenrollmentID(){
      return enrollmentID;
    }
    
    public String getdateOfBirth(){
      return dateOfBirth;
    }
    
    public String getcourseName(){
      return courseName;
    }
    
    public String getstudentName(){
      return studentName;
    }
    
    public String getdateofEnrollment(){
      return dateofEnrollment;
    }
    
    public int getcourseDuration(){
      return courseDuration; 
    }
    
    public int gettutionFee(){
      return tutionFee;
    }
    
    //method to set the course name
    public void setcourseName(String courseName){
      this.courseName =courseName;
    }
    //method to set the enrollmentID
    public void setenrollmentID(int enrollmentID){
      this.enrollmentID =enrollmentID;
    }
    
    //method to set the date of Birth
    public void setdateofBirth(String dateofBirth){
      this.dateOfBirth=dateofBirth;
    }
    
    //method to set the Student Name
    public void setstudentName(String studentName){
        this.studentName=studentName;
    }
    
    //method to set the Course Duration
    public void setcourseDuration(int courseDuration){
        this.courseDuration=courseDuration;
    }
    
    //method to set the Tution Fee
    public void settutionFee(int tutionFee){
        this.tutionFee=tutionFee;
    }
    
    //mutator method to set the date of Enrollment
    public void setdateOfEnrollment(String dateofEnrollment){
      this.dateofEnrollment =dateofEnrollment;
    }
    
    //displaying the output
    public void display(){
       if(getenrollmentID()==0 || getdateOfBirth().equals("")|| getcourseName().equals("") ||getstudentName().equals("")|| getdateofEnrollment().equals("")||getcourseDuration()==0||
        gettutionFee()==0)
       {
          System.out.println("Something is not set here");
        }  
     else
     {
       System.out.println("Enrollment ID: "+this.getenrollmentID());
       System.out.println("Date of Birth: "+this.getdateOfBirth());
       System.out.println("Course Name: "+this.getcourseName());
       System.out.println("Student Name: "+this.getstudentName());
       System.out.println("Date Of Enrollment: "+this.getdateofEnrollment());
       System.out.println("Course Duration: "+this.getcourseDuration());
       System.out.println("Tution Fee: "+this.gettutionFee());
      }
    }
}
  



    
       
       
   
        
    
