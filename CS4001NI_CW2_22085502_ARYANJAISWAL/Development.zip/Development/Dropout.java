//Dropout class is a subclass of Student class
public class Dropout extends Student{
    //Declaring the attributes
    private int numofRemainingModules;
    private int numofMonthsAttended;
    private String dateofDropout;
    private int remainingAmount;
    private boolean hasPaid;
    
    //Creating Constructors
    public Dropout(String dateofBirth,String studentName,int courseDuration,int tutionFee,int numofRemainingModules,int numofMonthsAttended,
                   String dateofDropout,int enrollmentID,String courseName,String dateofEnrollment){
                       
      //calling superclass constructor with four parameter
      super(dateofBirth,studentName,tutionFee,courseDuration);
      //calling setter methods of parent class
      super.setenrollmentID(enrollmentID);
      super.setcourseName(courseName);
      super.setdateOfEnrollment(dateofEnrollment);
       
      //Assigning the number in the constructors
      this.numofRemainingModules=numofRemainingModules;
      this.numofMonthsAttended=numofMonthsAttended;
      this.dateofDropout=dateofDropout;
      this.remainingAmount=0;
      this.hasPaid=false;
    }
    
    //Accesor method of Dropout class
    public int getnumofRemainingModules(){
        return this.numofRemainingModules;
    }
    public int getnumofMonthsAttended(){
        return this.numofMonthsAttended;
    }
    public String getdateofDropout(){
        return this.dateofDropout;
    }
    public int getremainingAmount(){
        return this.remainingAmount;
    }
    public boolean gethasPaid(){
        return this.hasPaid;
    }
    
    //Creating a method name bills payable
    public void billsPayable(){
        this.remainingAmount=(getcourseDuration()-this.numofMonthsAttended)* super.gettutionFee();
        if(remainingAmount==0){
          this.hasPaid=true;   
        }
        else{
            this.hasPaid=false;
        }
    }
    
    //Method to remove Student
    public void removeStudent(){
      if(hasPaid){
        super.setdateofBirth("");
        super.setcourseName("");
        super.setstudentName("");
        super.setdateOfEnrollment("");
        super.setcourseDuration(0);
        super.settutionFee(0);
        super.setenrollmentID(0);
        this.numofRemainingModules=0;
        this.numofMonthsAttended=0;
        this.dateofDropout="";
        this.remainingAmount=0;
        this.hasPaid=false;
      }
      else{
           System.out.println("All bills are not cleared:");
          }
      }
      
    //displaying attributes of Dropout class
      public void display(){
          super.display();
          System.out.println("Number of Remaining Modules: "+this.getnumofRemainingModules());
          System.out.println("Number of Months Attended: "+this.getnumofMonthsAttended());
          System.out.println("Date of Dropout: "+this.getdateofDropout());
          System.out.println("Remaining Amount: "+this.getremainingAmount());
     }
     
}
